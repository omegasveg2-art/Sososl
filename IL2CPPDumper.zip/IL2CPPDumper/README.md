# IL2CPPDumper (Android, root)

Runtime dumper for Unity IL2CPP targets on ARM64/ARMv7. Pulls real
`libil2cpp.so` + `global-metadata.dat` out of a *running* target process
instead of trusting whatever stub/placeholder sits on disk (common on
protected APKs: fake libs in the 0-4MB range, truncated metadata, etc).

## Why not just read the files off disk

Protected builds ship a loader stub as `libil2cpp.so` (often suspiciously
small, ~0-4MB) that unpacks/decrypts the real thing only in memory at
runtime, or mmaps metadata from an encrypted blob. Reading the on-disk
file gets you the stub. This tool attaches to the live process, walks
`/proc/pid/maps`, and dumps from there.

## How it works

1. `native/dumper` is a standalone executable (arm64-v8a + armeabi-v7a),
   pushed from the APK's `nativeLibraryDir` and run as `su -c`.
2. Resolves target pid from package name via `/proc/*/cmdline`.
3. Parses `/proc/pid/maps`, finds every mapping whose backing path ends in
   `libil2cpp.so`, groups PT_LOAD-equivalent ranges by that path.
4. Reads memory via `process_vm_readv`; falls back to
   `PTRACE_ATTACH` + `/proc/pid/mem` if that's EPERM (ptrace_scope).
5. Validates: ELF magic/class/machine must match, **and** the dynsym
   table must contain real IL2CPP exports (`il2cpp_init`,
   `il2cpp_domain_get`, `il2cpp_class_from_name`, ...). Size is never
   used as the sole signal — a correctly-sized fake is still rejected if
   the symbol table is wrong, and a small stub that happens to be real
   (just not yet decompressed sections) is still handed to the rebuild
   step rather than rejected on sight.
6. Rebuilds a loadable ELF from the memory image: for every PT_LOAD
   segment sets `p_offset = p_vaddr`, lays out the output file by vaddr
   so IDA/Ghidra load it like the original (standard "memory dump fix"
   used by every IL2CPP memory dumper).
7. For `global-metadata.dat`: if it's file-backed in `maps`, dumps the
   backing file directly. If it's only ever materialized in anonymous
   memory (encrypted-at-rest stub pattern), scans all readable anon
   regions for the `0xFAB11BAF` signature at offset 0, validates the
   header (version in known range, string-literal table offset/size
   non-zero, sane table count), and dumps that region.
8. Cross-validates lib + metadata (Unity/IL2CPP version compatibility
   table) before calling the dump successful. Emits a JSON report.

## Build

Build it yourself:

```
./gradlew assembleDebug
```

or just push to the repo / run the `build.yml` workflow manually
(Actions tab → Run workflow) and grab `app-debug.apk` from the run's
Artifacts.

## Use

1. Install on a **rooted** device/emulator (Magisk or similar — this
   needs `su`, there's no non-root path, Android sandboxes you out of
   another app's memory otherwise).
2. Launch target game, let it fully init (past the Unity splash).
3. Open IL2CPPDumper, type the target's package name, hit Dump.
4. Output lands in `/sdcard/Android/data/com.crez.il2cppdumper/files/dumps/<pkg>/`:
   `libil2cpp.so`, `global-metadata.dat`, `report.json`.

## Known limits

- Needs root. No Frida/Xposed path implemented (add one if the target
  has anti-ptrace that survives root — not in scope here).
- EM_AARCH64/EM_ARM only.
- Metadata-version compat table in `il2cpp_dumper.cpp` covers the common
  2019.x-2023.x range; add entries as needed, it's one array.
