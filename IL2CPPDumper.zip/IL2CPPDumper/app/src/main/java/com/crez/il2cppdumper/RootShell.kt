package com.crez.il2cppdumper

import java.io.BufferedReader
import java.io.InputStreamReader

object RootShell {

    data class Result(val exitCode: Int, val stdout: String, val stderr: String)

    fun isRootAvailable(): Boolean {
        return try {
            val p = ProcessBuilder("su", "-c", "id").redirectErrorStream(false).start()
            val out = p.inputStream.bufferedReader().readText()
            val code = p.waitFor()
            code == 0 && out.contains("uid=0")
        } catch (e: Exception) {
            false
        }
    }

    /** Runs `cmd` as root via `su -c`, blocking, with a hard timeout. */
    fun runAsRoot(cmd: String, timeoutSeconds: Long = 60): Result {
        return try {
            val process = ProcessBuilder("su", "-c", cmd)
                .redirectErrorStream(false)
                .start()

            val stdoutReader = BufferedReader(InputStreamReader(process.inputStream))
            val stderrReader = BufferedReader(InputStreamReader(process.errorStream))

            val stdout = StringBuilder()
            val stderr = StringBuilder()

            val stdoutThread = Thread {
                stdoutReader.forEachLine { stdout.append(it).append('\n') }
            }
            val stderrThread = Thread {
                stderrReader.forEachLine { stderr.append(it).append('\n') }
            }
            stdoutThread.start()
            stderrThread.start()

            val finished = process.waitFor(timeoutSeconds, java.util.concurrent.TimeUnit.SECONDS)
            if (!finished) {
                process.destroyForcibly()
                stdoutThread.join(2000)
                stderrThread.join(2000)
                return Result(-1, stdout.toString(), stderr.toString() + "\n[timed out]")
            }
            stdoutThread.join(2000)
            stderrThread.join(2000)
            Result(process.exitValue(), stdout.toString(), stderr.toString())
        } catch (e: Exception) {
            Result(-2, "", "su invocation failed: ${e.message}")
        }
    }
}
