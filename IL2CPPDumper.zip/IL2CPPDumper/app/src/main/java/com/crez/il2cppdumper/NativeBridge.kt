package com.crez.il2cppdumper

object NativeBridge {
    init {
        System.loadLibrary("il2cppdumper_jni")
    }

    external fun abiTag(): String
}
