package com.crez.il2cppdumper

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.crez.il2cppdumper.databinding.ActivityMainBinding
import java.io.File
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val abi = try {
            NativeBridge.abiTag()
        } catch (e: Throwable) {
            "unknown (${e.message})"
        }
        log("device ABI: $abi")

        binding.btnCheckRoot.setOnClickListener {
            log("checking root access...")
            thread {
                val ok = RootShell.isRootAvailable()
                runOnUiThread {
                    log(if (ok) "root: OK" else "root: NOT AVAILABLE -- this tool needs a rooted device")
                }
            }
        }

        binding.btnDump.setOnClickListener {
            val pkg = binding.editPackage.text?.toString()?.trim().orEmpty()
            if (pkg.isEmpty()) {
                Toast.makeText(this, "enter a target package name first", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            runDump(pkg)
        }
    }

    private fun runDump(pkg: String) {
        binding.btnDump.isEnabled = false
        log("---")
        log("starting dump for $pkg")

        thread {
            // Packaged as libdumper.so (see CMakeLists.txt) so AGP's native
            // packaging picks it up and extracts it to a real file here --
            // it's a plain ELF executable under the hood, not a shared lib.
            val dumperPath = File(applicationInfo.nativeLibraryDir, "libdumper.so").absolutePath
            val outDir = File(getExternalFilesDir(null), "dumps/$pkg").absolutePath

            // Make sure it's executable even if the device mounted the
            // native lib dir without exec bits carried over (rare, but
            // some custom ROMs strip +x on extraction).
            RootShell.runAsRoot("chmod 755 '$dumperPath'", timeoutSeconds = 10)

            val checkExists = RootShell.runAsRoot("test -f '$dumperPath' && echo FOUND || echo MISSING", 10)
            if (!checkExists.stdout.contains("FOUND")) {
                runOnUiThread {
                    log("ERROR: dumper binary not found at $dumperPath")
                    log("(APK may not have packaged the native executable for this ABI)")
                    binding.btnDump.isEnabled = true
                }
                return@thread
            }

            val cmd = "'$dumperPath' '$pkg' '$outDir'"
            runOnUiThread { log("running: $cmd") }

            val result = RootShell.runAsRoot(cmd, timeoutSeconds = 120)

            runOnUiThread {
                if (result.stdout.isNotBlank()) log(result.stdout.trim())
                if (result.stderr.isNotBlank()) log("[stderr] " + result.stderr.trim())
                log("exit code: ${result.exitCode}")
                log(if (result.exitCode == 0) "DUMP OK -> $outDir" else "DUMP FAILED, see notes above")
                binding.btnDump.isEnabled = true
            }
        }
    }

    private fun log(line: String) {
        binding.textLog.append(line)
        binding.textLog.append("\n")
        binding.scrollLog.post { binding.scrollLog.fullScroll(android.view.View.FOCUS_DOWN) }
    }
}
