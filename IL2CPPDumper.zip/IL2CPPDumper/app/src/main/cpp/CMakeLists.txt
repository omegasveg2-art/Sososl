cmake_minimum_required(VERSION 3.22.1)
project(il2cppdumper)

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)

# Standalone executable, pushed from nativeLibraryDir and run via `su -c`.
# It is NOT loaded into the target process — it reads the target's memory
# from the outside via process_vm_readv / ptrace, as root.
#
# Named "libdumper.so" on purpose: AGP's native-build packaging only
# auto-copies build products matching the lib*.so naming convention into
# lib/<abi>/ inside the APK (and, with android:extractNativeLibs="true",
# extracts them to nativeLibraryDir as real executable files at install
# time). It's still a plain ELF executable, not a shared object -- we
# execve it directly via `su -c`, never dlopen it. The .so name is just
# how it hitches a ride through Android's packaging pipeline.
add_executable(dumper
    dumper_main.cpp
    proc_maps.cpp
    elf_reader.cpp
    il2cpp_dumper.cpp
)
set_target_properties(dumper PROPERTIES
    PREFIX ""
    SUFFIX ""
    OUTPUT_NAME "libdumper.so"
)

target_include_directories(dumper PRIVATE ${CMAKE_CURRENT_SOURCE_DIR})
target_compile_options(dumper PRIVATE -Wall -Wextra -fno-rtti)
target_link_options(dumper PRIVATE -static-libstdc++)
target_link_libraries(dumper log)

# A trivial JNI shim so Gradle/AGP is happy packaging a .so per-ABI too
# (not required for operation — the app shells out to `dumper`, it never
# dlopens this). Keeps the native build graph conventional.
add_library(il2cppdumper_jni SHARED jni_shim.cpp)
target_link_libraries(il2cppdumper_jni log)
