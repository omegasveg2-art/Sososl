#pragma once
#include <cstdint>
#include <string>
#include <vector>
#include <sys/types.h>

struct MapRegion {
    uintptr_t start = 0;
    uintptr_t end = 0;
    bool r = false, w = false, x = false, p_shared = false; // p_shared=false means private
    uint64_t file_offset = 0;
    std::string dev;
    uint64_t inode = 0;
    std::string path; // may be empty for anonymous mappings
};

// Reads /proc/<pid>/maps. Caller must already be root (or same uid) or
// this returns an empty vector (ESRCH/EACCES both just look like "no maps"
// to the parser, so the real error is logged separately by the caller).
std::vector<MapRegion> read_proc_maps(pid_t pid);

// Scans /proc/*/cmdline for an exact package-name match. Returns -1 if
// not running. Picks the lowest-numbered matching pid if the process
// forked zygote children sharing the same cmdline (rare, but some apps
// run a renderer/service process under the same name).
pid_t find_pid_by_package(const std::string &package);

// Groups every MapRegion whose `path` ends with `suffix` (e.g.
// "libil2cpp.so" or "global-metadata.dat"), in address order. Several
// PT_LOAD segments of the same file show up as separate map entries.
std::vector<MapRegion> regions_matching_suffix(const std::vector<MapRegion> &maps,
                                                const std::string &suffix);
