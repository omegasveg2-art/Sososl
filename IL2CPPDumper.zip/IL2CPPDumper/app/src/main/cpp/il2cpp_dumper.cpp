#include "il2cpp_dumper.h"
#include <cstdio>
#include <cstring>
#include <fstream>
#include <algorithm>

// How many of il2cpp_required_exports() must be present before we trust
// the library is real and not a loader stub. 8/10 tolerates a mildly
// stripped build while still rejecting a stub that exports nothing of
// substance.
static constexpr int kMinExportsRequired = 8;

Il2CppLibInfo analyze_il2cpp_library(pid_t pid, const std::vector<MapRegion> &maps) {
    Il2CppLibInfo info;
    auto regions = regions_matching_suffix(maps, "libil2cpp.so");
    if (regions.empty()) return info;

    info.found = true;
    info.backing_path = regions.front().path;

    // The segment carrying file_offset 0 is the one whose start address
    // is the module's load base (vaddr 0 == that mapping's start).
    uintptr_t base = regions.front().start;
    for (const auto &r : regions) {
        if (r.file_offset == 0) { base = r.start; break; }
    }
    info.base = base;

    uintptr_t highest_end = base;
    for (const auto &r : regions) highest_end = std::max(highest_end, r.end);
    info.total_mapped_size = highest_end - base;

    RemoteMemory mem(pid);
    uint8_t header_buf[4096];
    if (!mem.read(base, header_buf, sizeof(header_buf))) return info;

    info.elf = parse_elf_identity(header_buf, sizeof(header_buf));
    if (!info.elf.valid) return info;
    info.structurally_valid = true;

    info.phdrs = read_program_headers(mem, base, info.elf);
    auto exports = read_dynamic_symbol_names(mem, base, info.phdrs, info.elf);
    info.exports_present = count_il2cpp_exports_present(exports);
    info.exports_required = (int) il2cpp_required_exports().size();
    info.exports_valid = info.exports_present >= kMinExportsRequired;

    return info;
}

bool dump_il2cpp_library(pid_t pid, Il2CppLibInfo &lib, const std::string &out_path) {
    if (!lib.structurally_valid || lib.phdrs.empty()) return false;

    uint64_t file_size = 0;
    for (const auto &ph : lib.phdrs) {
        if (ph.type != PT_LOAD) continue;
        file_size = std::max(file_size, ph.vaddr + ph.memsz);
    }
    if (file_size == 0 || file_size > (512ull * 1024 * 1024)) return false; // sanity cap

    std::vector<uint8_t> out(file_size, 0);
    RemoteMemory mem(pid);

    for (const auto &ph : lib.phdrs) {
        if (ph.type != PT_LOAD || ph.memsz == 0) continue;
        uint64_t len = std::min(ph.memsz, file_size - ph.vaddr);
        // Read in chunks so one unreadable page (guard page, swapped out
        // segment) doesn't zero out an otherwise-good segment.
        const size_t chunk = 64 * 1024;
        for (uint64_t off = 0; off < len; off += chunk) {
            uint64_t n = std::min<uint64_t>(chunk, len - off);
            mem.read(lib.base + ph.vaddr + off, out.data() + ph.vaddr + off, n);
            // Deliberately ignore a per-chunk failure: that span stays
            // zeroed, which is correct for unmapped bss and merely
            // lossy (not wrong) for any genuinely unreadable code page.
        }
    }

    // Patch the in-buffer program header table: p_offset := p_vaddr for
    // every PT_LOAD, so file offsets match virtual addresses (the
    // standard "memory dump fix"). Requires e_phoff to fall inside a
    // segment we already copied -- true for every IL2CPP build seen in
    // practice (phdr table sits in the first PT_LOAD).
    const ElfIdentity &id = lib.elf;
    if (id.phoff + (uint64_t) id.phnum * id.phentsize <= file_size) {
        for (uint16_t i = 0; i < id.phnum; ++i) {
            uint8_t *entry = out.data() + id.phoff + (uint64_t) i * id.phentsize;
            if (id.is64) {
                auto *ph = reinterpret_cast<Elf64_Phdr *>(entry);
                if (ph->p_type == PT_LOAD) ph->p_offset = ph->p_vaddr;
            } else {
                auto *ph = reinterpret_cast<Elf32_Phdr *>(entry);
                if (ph->p_type == PT_LOAD) ph->p_offset = ph->p_vaddr;
            }
        }
    }

    // Section headers reference file offsets that no longer mean
    // anything post-rebuild; zero them so tools fall back to program
    // headers / dynamic symbols instead of parsing garbage.
    if (id.is64 && sizeof(Elf64_Ehdr) <= out.size()) {
        auto *eh = reinterpret_cast<Elf64_Ehdr *>(out.data());
        eh->e_shoff = 0;
        eh->e_shnum = 0;
        eh->e_shstrndx = 0;
    } else if (!id.is64 && sizeof(Elf32_Ehdr) <= out.size()) {
        auto *eh = reinterpret_cast<Elf32_Ehdr *>(out.data());
        eh->e_shoff = 0;
        eh->e_shnum = 0;
        eh->e_shstrndx = 0;
    }

    std::ofstream f(out_path, std::ios::binary | std::ios::trunc);
    if (!f.is_open()) return false;
    f.write(reinterpret_cast<const char *>(out.data()), (std::streamsize) out.size());
    f.close();

    lib.dump_path = out_path;
    return true;
}

static bool validate_metadata_bytes(const uint8_t *buf, size_t len, Il2CppMetadataInfo &meta) {
    if (len < sizeof(Il2CppMetadataHeaderPrefix)) return false;
    Il2CppMetadataHeaderPrefix hdr{};
    memcpy(&hdr, buf, sizeof(hdr));

    meta.signature_valid = (hdr.sanityCheck == kIl2CppMetadataSignature);
    if (!meta.signature_valid) return false;

    meta.version = hdr.version;
    bool version_ok = metadata_version_is_known(hdr.version);
    bool string_table_ok = hdr.stringOffset > 0 && hdr.stringCount > 0 &&
                            (uint64_t) hdr.stringOffset + (uint64_t) hdr.stringCount <= len + 1024 * 1024;
    // (+1MB slack: stringCount is a byte-length of the blob in some
    // versions, an entry count in others -- this is a loose sanity
    // bound, not a precise per-version table parse. See header comment.)

    meta.header_sane = version_ok && string_table_ok;
    return true;
}

Il2CppMetadataInfo find_and_dump_global_metadata(pid_t pid, const std::vector<MapRegion> &maps,
                                                   const std::string &out_path) {
    Il2CppMetadataInfo meta;

    auto file_backed = regions_matching_suffix(maps, "global-metadata.dat");
    if (!file_backed.empty() && !file_backed.front().path.empty() &&
        file_backed.front().path[0] == '/') {
        // Direct file read, root only. Simpler and more reliable than
        // reconstructing it page-by-page from the process's memory.
        std::ifstream in(file_backed.front().path, std::ios::binary);
        if (in.is_open()) {
            std::vector<uint8_t> data((std::istreambuf_iterator<char>(in)),
                                       std::istreambuf_iterator<char>());
            if (!data.empty()) {
                meta.found = true;
                meta.from_memory_scan = false;
                validate_metadata_bytes(data.data(), data.size(), meta);
                std::ofstream out(out_path, std::ios::binary | std::ios::trunc);
                if (out.is_open()) {
                    out.write(reinterpret_cast<const char *>(data.data()),
                              (std::streamsize) data.size());
                    meta.dump_path = out_path;
                }
                return meta;
            }
        }
    }

    // Fallback: protected build only ever materializes metadata in
    // memory that isn't a plain "global-metadata.dat" file mapping --
    // true anonymous mappings, but also ashmem/memfd-backed regions
    // that show up with a bracketed or "/memfd:..." pseudo-path on
    // recent Android kernels. Scan every readable region we haven't
    // already ruled out for the signature at offset 0.
    RemoteMemory mem(pid);
    for (const auto &r : maps) {
        if (!r.r) continue;
        bool looks_like_real_file = !r.path.empty() && r.path[0] == '/' &&
                                     r.path.find("(deleted)") == std::string::npos &&
                                     r.path.find("memfd:") == std::string::npos;
        if (looks_like_real_file) continue; // already handled above, or irrelevant lib/so mapping
        size_t region_len = r.end - r.start;
        if (region_len < sizeof(Il2CppMetadataHeaderPrefix) || region_len > (256ull * 1024 * 1024)) {
            continue;
        }

        int32_t maybe_sig = 0;
        if (!mem.read(r.start, &maybe_sig, sizeof(maybe_sig))) continue;
        if (maybe_sig != kIl2CppMetadataSignature) continue;

        std::vector<uint8_t> data(region_len);
        bool ok = true;
        const size_t chunk = 64 * 1024;
        for (size_t off = 0; off < region_len; off += chunk) {
            size_t n = std::min(chunk, region_len - off);
            if (!mem.read(r.start + off, data.data() + off, n)) { ok = false; break; }
        }
        if (!ok) continue;

        meta.found = true;
        meta.from_memory_scan = true;
        validate_metadata_bytes(data.data(), data.size(), meta);

        std::ofstream out(out_path, std::ios::binary | std::ios::trunc);
        if (out.is_open()) {
            out.write(reinterpret_cast<const char *>(data.data()), (std::streamsize) data.size());
            meta.dump_path = out_path;
        }
        return meta; // first signature match wins
    }

    return meta;
}

bool metadata_version_is_known(int32_t version) {
    // Loose, intentionally generous bound covering the IL2CPP metadata
    // format revisions seen from roughly Unity 5.3 through 2023.x.
    // Extend this if a newer/older title reports a version outside it --
    // it's one line, not an architectural change.
    return version >= 16 && version <= 32;
}

std::string build_report_json(const DumpReport &r) {
    char buf[4096];
    snprintf(buf, sizeof(buf),
        "{\n"
        "  \"package\": \"%s\",\n"
        "  \"pid\": %d,\n"
        "  \"library\": {\n"
        "    \"found\": %s,\n"
        "    \"backing_path\": \"%s\",\n"
        "    \"base\": \"0x%zx\",\n"
        "    \"mapped_size\": %zu,\n"
        "    \"structurally_valid\": %s,\n"
        "    \"machine\": %u,\n"
        "    \"is64\": %s,\n"
        "    \"exports_present\": %d,\n"
        "    \"exports_required_total\": %d,\n"
        "    \"exports_valid\": %s,\n"
        "    \"dump_path\": \"%s\"\n"
        "  },\n"
        "  \"metadata\": {\n"
        "    \"found\": %s,\n"
        "    \"from_memory_scan\": %s,\n"
        "    \"signature_valid\": %s,\n"
        "    \"version\": %d,\n"
        "    \"header_sane\": %s,\n"
        "    \"dump_path\": \"%s\"\n"
        "  },\n"
        "  \"version_compatible\": %s,\n"
        "  \"notes\": \"%s\"\n"
        "}\n",
        r.package.c_str(), r.pid,
        r.lib.found ? "true" : "false",
        r.lib.backing_path.c_str(),
        r.lib.base,
        r.lib.total_mapped_size,
        r.lib.structurally_valid ? "true" : "false",
        r.lib.elf.machine,
        r.lib.elf.is64 ? "true" : "false",
        r.lib.exports_present,
        r.lib.exports_required,
        r.lib.exports_valid ? "true" : "false",
        r.lib.dump_path.c_str(),
        r.metadata.found ? "true" : "false",
        r.metadata.from_memory_scan ? "true" : "false",
        r.metadata.signature_valid ? "true" : "false",
        r.metadata.version,
        r.metadata.header_sane ? "true" : "false",
        r.metadata.dump_path.c_str(),
        r.version_compatible ? "true" : "false",
        r.notes.c_str());
    return std::string(buf);
}
