#pragma once
#include <cstdint>
#include <string>
#include <vector>
#include "proc_maps.h"
#include "elf_reader.h"

// Stable across essentially every IL2CPP metadata format revision --
// this is the part every version's parser agrees on. Table offsets/
// counts past these two fields moved around release to release (Unity
// restructured the header several times, most notably around 2019.3 and
// again around 2021.x), so this tool does not hardcode table layouts --
// it validates what's stable (signature + version in a known range,
// string-literal table non-degenerate) and leaves full table parsing
// as a per-version extension (see README "Known limits").
struct Il2CppMetadataHeaderPrefix {
    int32_t sanityCheck = 0;   // must be 0xFAB11BAF
    int32_t version = 0;
    int32_t stringLiteralOffset = 0;
    int32_t stringLiteralCount = 0;
    int32_t stringLiteralDataOffset = 0;
    int32_t stringLiteralDataCount = 0;
    int32_t stringOffset = 0;
    int32_t stringCount = 0;
};

static constexpr int32_t kIl2CppMetadataSignature = (int32_t) 0xFAB11BAFu;

struct Il2CppLibInfo {
    bool found = false;
    bool structurally_valid = false; // ELF header/machine/class checks out
    bool exports_valid = false;      // has enough real IL2CPP exports
    uintptr_t base = 0;
    size_t total_mapped_size = 0;
    std::string backing_path;
    ElfIdentity elf;
    int exports_present = 0;
    int exports_required = 0;
    std::string dump_path; // where it was written, once dumped
    std::vector<ProgramHeader> phdrs; // populated by analyze_il2cpp_library
};

struct Il2CppMetadataInfo {
    bool found = false;
    bool signature_valid = false;
    bool header_sane = false;
    int32_t version = 0;
    bool from_memory_scan = false; // true if it wasn't file-backed in maps
    std::string dump_path;
};

struct DumpReport {
    std::string package;
    pid_t pid = 0;
    Il2CppLibInfo lib;
    Il2CppMetadataInfo metadata;
    bool version_compatible = false;
    std::string notes;
};

// Finds every mapping backing `libil2cpp.so`, reads+validates the ELF
// header and dynamic exports from the *live process* (never trusts
// on-disk file size), and returns a populated Il2CppLibInfo. Does not
// write anything to disk yet -- call dump_il2cpp_library for that.
Il2CppLibInfo analyze_il2cpp_library(pid_t pid, const std::vector<MapRegion> &maps);

// Rebuilds a loadable ELF file from the live memory image: each PT_LOAD
// segment is written at file offset == its vaddr (the standard "memory
// dump fix" every IL2CPP dumper applies), so disassemblers load it with
// the same layout the runtime linker used -- cross references line up.
bool dump_il2cpp_library(pid_t pid, Il2CppLibInfo &lib, const std::string &out_path);

// Finds global-metadata.dat: prefers a file-backed mapping (dumps the
// backing file byte-for-byte); falls back to scanning anonymous regions
// for the 0xFAB11BAF signature at offset 0 (protected builds that only
// ever materialize metadata in memory). Validates the stable header
// prefix either way.
Il2CppMetadataInfo find_and_dump_global_metadata(pid_t pid, const std::vector<MapRegion> &maps,
                                                   const std::string &out_path);

// Loose compatibility gate: known-good metadata version range. Doesn't
// claim to know every Unity release, just rejects obviously-wrong
// values (corrupted dump, wrong signature position, etc).
bool metadata_version_is_known(int32_t version);

std::string build_report_json(const DumpReport &r);
