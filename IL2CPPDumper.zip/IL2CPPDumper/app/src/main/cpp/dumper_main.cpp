// Standalone executable -- NOT a shared lib loaded into the target.
// Pushed from the APK's nativeLibraryDir and executed as `su -c`.
// Usage: dumper <package.name> <output_dir>
#include <cstdio>
#include <cstdlib>
#include <unistd.h>
#include <sys/stat.h>
#include <fstream>
#include "proc_maps.h"
#include "il2cpp_dumper.h"

static void mkdir_p(const std::string &path) {
    std::string cur;
    for (size_t i = 0; i <= path.size(); ++i) {
        if (i == path.size() || path[i] == '/') {
            if (!cur.empty()) mkdir(cur.c_str(), 0755);
        }
        if (i < path.size()) cur.push_back(path[i]);
    }
}

int main(int argc, char **argv) {
    if (argc < 3) {
        fprintf(stderr, "usage: %s <package.name> <output_dir>\n", argv[0]);
        return 2;
    }
    if (geteuid() != 0) {
        fprintf(stderr, "ERROR: must run as root (su -c), got uid=%d\n", geteuid());
        return 3;
    }

    std::string package = argv[1];
    std::string out_dir = argv[2];
    mkdir_p(out_dir);

    pid_t pid = find_pid_by_package(package);
    if (pid <= 0) {
        fprintf(stderr, "ERROR: process not found for package '%s' -- is it running?\n",
                package.c_str());
        return 4;
    }
    fprintf(stdout, "target pid: %d\n", pid);

    auto maps = read_proc_maps(pid);
    if (maps.empty()) {
        fprintf(stderr, "ERROR: could not read /proc/%d/maps (ptrace blocked even as root?)\n", pid);
        return 5;
    }

    DumpReport report;
    report.package = package;
    report.pid = pid;

    report.lib = analyze_il2cpp_library(pid, maps);
    if (!report.lib.found) {
        report.notes = "libil2cpp.so not found in target's memory maps";
    } else if (!report.lib.structurally_valid) {
        report.notes = "libil2cpp.so mapping found but ELF header is invalid/unreadable";
    } else if (!report.lib.exports_valid) {
        char note[160];
        snprintf(note, sizeof(note),
                 "ELF header valid but only %d/%d required IL2CPP exports present -- "
                 "this is very likely a loader stub, not the real library",
                 report.lib.exports_present, report.lib.exports_required);
        report.notes = note;
    } else {
        std::string lib_out = out_dir + "/libil2cpp.so";
        if (dump_il2cpp_library(pid, report.lib, lib_out)) {
            fprintf(stdout, "library dumped: %s (%zu bytes mapped)\n",
                    lib_out.c_str(), report.lib.total_mapped_size);
        } else {
            report.notes += "library validated but dump write failed; ";
        }
    }

    std::string meta_out = out_dir + "/global-metadata.dat";
    report.metadata = find_and_dump_global_metadata(pid, maps, meta_out);
    if (!report.metadata.found) {
        report.notes += "global-metadata.dat not found (not file-backed and no "
                         "0xFAB11BAF signature in any scanned anonymous region)";
    } else {
        fprintf(stdout, "metadata dumped: %s (memory_scan=%s, signature_valid=%s, version=%d)\n",
                report.metadata.dump_path.c_str(),
                report.metadata.from_memory_scan ? "yes" : "no",
                report.metadata.signature_valid ? "yes" : "no",
                report.metadata.version);
    }

    report.version_compatible = report.lib.exports_valid && report.metadata.header_sane;

    std::string report_path = out_dir + "/report.json";
    std::string json = build_report_json(report);
    {
        std::ofstream f(report_path, std::ios::trunc);
        f << json;
    }
    fprintf(stdout, "%s", json.c_str());

    bool success = report.lib.exports_valid && report.metadata.found && report.metadata.header_sane;
    return success ? 0 : 1;
}
