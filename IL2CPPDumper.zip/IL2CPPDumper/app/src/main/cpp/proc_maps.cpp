#include "proc_maps.h"
#include <cstdio>
#include <cstring>
#include <dirent.h>
#include <fstream>
#include <sstream>
#include <algorithm>

std::vector<MapRegion> read_proc_maps(pid_t pid) {
    std::vector<MapRegion> out;
    char path[64];
    snprintf(path, sizeof(path), "/proc/%d/maps", pid);
    std::ifstream f(path);
    if (!f.is_open()) return out;

    std::string line;
    while (std::getline(f, line)) {
        // format: start-end perms offset dev inode  pathname
        MapRegion r;
        unsigned long long start = 0, end = 0, off = 0, ino = 0;
        char perms[8] = {0};
        char dev[16] = {0};
        int path_idx = 0;

        int n = sscanf(line.c_str(), "%llx-%llx %7s %llx %15s %llu %n",
                        &start, &end, perms, &off, dev, &ino, &path_idx);
        if (n < 6) continue;

        r.start = (uintptr_t) start;
        r.end = (uintptr_t) end;
        r.r = strchr(perms, 'r') != nullptr;
        r.w = strchr(perms, 'w') != nullptr;
        r.x = strchr(perms, 'x') != nullptr;
        r.p_shared = perms[3] == 's';
        r.file_offset = off;
        r.dev = dev;
        r.inode = ino;

        if (path_idx < (int) line.size()) {
            std::string tail = line.substr(path_idx);
            // trim leading spaces
            size_t s = tail.find_first_not_of(' ');
            if (s != std::string::npos) r.path = tail.substr(s);
        }
        out.push_back(r);
    }
    return out;
}

pid_t find_pid_by_package(const std::string &package) {
    DIR *d = opendir("/proc");
    if (!d) return -1;

    pid_t best = -1;
    struct dirent *ent;
    while ((ent = readdir(d)) != nullptr) {
        if (ent->d_type != DT_DIR) continue;
        bool numeric = ent->d_name[0] != '\0';
        for (const char *c = ent->d_name; *c; ++c) {
            if (*c < '0' || *c > '9') { numeric = false; break; }
        }
        if (!numeric) continue;

        pid_t pid = (pid_t) atoi(ent->d_name);
        char cmdline_path[64];
        snprintf(cmdline_path, sizeof(cmdline_path), "/proc/%d/cmdline", pid);
        std::ifstream cf(cmdline_path, std::ios::binary);
        if (!cf.is_open()) continue;
        std::string cmdline((std::istreambuf_iterator<char>(cf)),
                             std::istreambuf_iterator<char>());
        // cmdline is NUL-separated argv; argv[0] is the process name for
        // app processes (e.g. "com.foo.bar" or "com.foo.bar:service").
        std::string name = cmdline.c_str(); // stops at first NUL
        if (name == package) {
            if (best == -1 || pid < best) best = pid;
        }
    }
    closedir(d);
    return best;
}

std::vector<MapRegion> regions_matching_suffix(const std::vector<MapRegion> &maps,
                                                const std::string &suffix) {
    std::vector<MapRegion> out;
    for (const auto &m : maps) {
        if (m.path.size() >= suffix.size() &&
            m.path.compare(m.path.size() - suffix.size(), suffix.size(), suffix) == 0) {
            out.push_back(m);
        }
    }
    std::sort(out.begin(), out.end(), [](const MapRegion &a, const MapRegion &b) {
        return a.start < b.start;
    });
    return out;
}
