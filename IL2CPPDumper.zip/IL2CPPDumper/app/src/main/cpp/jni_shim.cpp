// Not used for any dumping logic -- all real work happens in the
// standalone `dumper` executable (see dumper_main.cpp), run as root via
// `su -c`. This shim only exists so Gradle/AGP packages a conventional
// per-ABI .so alongside it; MainActivity calls it once to confirm the
// native toolchain matches the running ABI before it bothers shelling
// out to `dumper`.
#include <jni.h>
#include <string>

extern "C" JNIEXPORT jstring JNICALL
Java_com_crez_il2cppdumper_NativeBridge_abiTag(JNIEnv *env, jobject /*thiz*/) {
#if defined(__aarch64__)
    return env->NewStringUTF("arm64-v8a");
#elif defined(__arm__)
    return env->NewStringUTF("armeabi-v7a");
#else
    return env->NewStringUTF("unsupported");
#endif
}
