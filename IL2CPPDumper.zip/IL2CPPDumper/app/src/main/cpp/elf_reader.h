#pragma once
#include <cstdint>
#include <string>
#include <vector>
#include <set>
#include <sys/types.h>
#include <elf.h>

// ---- remote memory I/O -----------------------------------------------
// Tries process_vm_readv first (no ptrace needed if the caller has
// CAP_SYS_PTRACE / is root and yama ptrace_scope allows it). Falls back
// to PTRACE_ATTACH + /proc/pid/mem, which works even when
// /proc/sys/kernel/yama/ptrace_scope=1 blocks the readv path, because
// an attached tracer is explicitly exempted.
class RemoteMemory {
public:
    explicit RemoteMemory(pid_t pid);
    ~RemoteMemory();

    // Reads `len` bytes from the target's address space at `addr` into
    // `out`. Returns false on any failure (partial reads are rejected --
    // a dump either got the whole segment or didn't).
    bool read(uintptr_t addr, void *out, size_t len);

    bool ok() const { return pid_ > 0; }

private:
    pid_t pid_;
    bool attached_ = false; // true if we had to PTRACE_ATTACH
    int mem_fd_ = -1;       // /proc/pid/mem, opened lazily on first fallback
};

// ---- ELF header validation --------------------------------------------
struct ElfIdentity {
    bool valid = false;
    bool is64 = false;
    uint16_t machine = 0; // EM_AARCH64 or EM_ARM
    uint64_t entry = 0;
    uint64_t phoff = 0;
    uint16_t phentsize = 0;
    uint16_t phnum = 0;
    uint64_t shoff = 0;
    uint16_t shentsize = 0;
    uint16_t shnum = 0;
    uint16_t shstrndx = 0;
};

// Validates the e_ident magic/class/machine fields of a buffer that
// starts at a mapped ELF header (the first page of libil2cpp.so as seen
// in /proc/pid/maps). Does NOT trust file size -- a stub can have a
// perfectly valid-looking ELF header and still not be the real library,
// which is why this is only step one of validation (see has_il2cpp_exports).
ElfIdentity parse_elf_identity(const uint8_t *buf, size_t len);

struct ProgramHeader {
    uint32_t type = 0;
    uint32_t flags = 0;
    uint64_t offset = 0;
    uint64_t vaddr = 0;
    uint64_t filesz = 0;
    uint64_t memsz = 0;
    uint64_t align = 0;
};

// Reads the program header table out of remote memory at base+phoff.
std::vector<ProgramHeader> read_program_headers(RemoteMemory &mem, uintptr_t base,
                                                  const ElfIdentity &id);

// Locates PT_DYNAMIC among the program headers, walks the DT_* tags, and
// resolves every exported dynamic symbol name it can find via DT_SYMTAB/
// DT_STRTAB (+ DT_HASH or DT_GNU_HASH to bound the symbol count). All
// addresses here are *virtual* addresses in the target process, read
// through `mem` at base+vaddr (base = this mapping's load bias).
std::set<std::string> read_dynamic_symbol_names(RemoteMemory &mem, uintptr_t base,
                                                  const std::vector<ProgramHeader> &phdrs,
                                                  const ElfIdentity &id);

// The minimum export set every real libil2cpp.so has. A stub/loader
// lib will be missing most or all of these even if its ELF header and
// file size look plausible.
const std::vector<std::string> &il2cpp_required_exports();

// Returns how many of il2cpp_required_exports() were found. Validation
// policy (how many is "enough") lives in il2cpp_dumper.cpp, not here.
int count_il2cpp_exports_present(const std::set<std::string> &found);
