#include "elf_reader.h"
#include <cstring>
#include <cstdio>
#include <unistd.h>
#include <fcntl.h>
#include <sys/uio.h>
#include <sys/ptrace.h>
#include <sys/wait.h>
#include <sys/syscall.h>

// ---------------------------------------------------------------- RemoteMemory

static ssize_t raw_process_vm_readv(pid_t pid, uintptr_t addr, void *buf, size_t len) {
    struct iovec local = { buf, len };
    struct iovec remote = { (void *) addr, len };
#ifdef SYS_process_vm_readv
    return syscall(SYS_process_vm_readv, pid, &local, 1, &remote, 1, 0);
#else
    (void) pid; (void) addr; (void) buf; (void) len;
    errno = ENOSYS;
    return -1;
#endif
}

RemoteMemory::RemoteMemory(pid_t pid) : pid_(pid) {}

RemoteMemory::~RemoteMemory() {
    if (mem_fd_ >= 0) close(mem_fd_);
    if (attached_) {
        ptrace(PTRACE_DETACH, pid_, nullptr, nullptr);
    }
}

bool RemoteMemory::read(uintptr_t addr, void *out, size_t len) {
    if (pid_ <= 0 || len == 0) return false;

    // Fast path: process_vm_readv, no attach needed.
    ssize_t n = raw_process_vm_readv(pid_, addr, out, len);
    if (n == (ssize_t) len) return true;

    // Fallback: PTRACE_ATTACH once, then read via /proc/pid/mem. This is
    // what survives yama ptrace_scope=1 (restricted) because an actual
    // tracer relationship is established.
    if (!attached_) {
        if (ptrace(PTRACE_ATTACH, pid_, nullptr, nullptr) != 0) {
            return false;
        }
        int status = 0;
        waitpid(pid_, &status, 0);
        attached_ = true;
    }

    if (mem_fd_ < 0) {
        char path[64];
        snprintf(path, sizeof(path), "/proc/%d/mem", pid_);
        mem_fd_ = open(path, O_RDONLY);
        if (mem_fd_ < 0) return false;
    }

    ssize_t got = pread(mem_fd_, out, len, (off_t) addr);
    return got == (ssize_t) len;
}

// ---------------------------------------------------------------- ELF identity

ElfIdentity parse_elf_identity(const uint8_t *buf, size_t len) {
    ElfIdentity id;
    if (len < sizeof(Elf64_Ehdr)) return id;
    if (memcmp(buf, ELFMAG, SELFMAG) != 0) return id;

    uint8_t ei_class = buf[EI_CLASS];
    if (ei_class != ELFCLASS64 && ei_class != ELFCLASS32) return id;
    id.is64 = (ei_class == ELFCLASS64);

    if (id.is64) {
        const auto *eh = reinterpret_cast<const Elf64_Ehdr *>(buf);
        id.machine = eh->e_machine;
        id.entry = eh->e_entry;
        id.phoff = eh->e_phoff;
        id.phentsize = eh->e_phentsize;
        id.phnum = eh->e_phnum;
        id.shoff = eh->e_shoff;
        id.shentsize = eh->e_shentsize;
        id.shnum = eh->e_shnum;
        id.shstrndx = eh->e_shstrndx;
    } else {
        if (len < sizeof(Elf32_Ehdr)) return id;
        const auto *eh = reinterpret_cast<const Elf32_Ehdr *>(buf);
        id.machine = eh->e_machine;
        id.entry = eh->e_entry;
        id.phoff = eh->e_phoff;
        id.phentsize = eh->e_phentsize;
        id.phnum = eh->e_phnum;
        id.shoff = eh->e_shoff;
        id.shentsize = eh->e_shentsize;
        id.shnum = eh->e_shnum;
        id.shstrndx = eh->e_shstrndx;
    }

    if (id.machine != EM_AARCH64 && id.machine != EM_ARM) return id;
    if (id.phnum == 0 || id.phnum > 64) return id; // sanity cap, real libs have a handful

    id.valid = true;
    return id;
}

std::vector<ProgramHeader> read_program_headers(RemoteMemory &mem, uintptr_t base,
                                                  const ElfIdentity &id) {
    std::vector<ProgramHeader> out;
    if (!id.valid) return out;

    for (uint16_t i = 0; i < id.phnum; ++i) {
        ProgramHeader ph;
        uintptr_t addr = base + id.phoff + (uint64_t) i * id.phentsize;

        if (id.is64) {
            Elf64_Phdr raw{};
            if (!mem.read(addr, &raw, sizeof(raw))) break;
            ph.type = raw.p_type;
            ph.flags = raw.p_flags;
            ph.offset = raw.p_offset;
            ph.vaddr = raw.p_vaddr;
            ph.filesz = raw.p_filesz;
            ph.memsz = raw.p_memsz;
            ph.align = raw.p_align;
        } else {
            Elf32_Phdr raw{};
            if (!mem.read(addr, &raw, sizeof(raw))) break;
            ph.type = raw.p_type;
            ph.flags = raw.p_flags;
            ph.offset = raw.p_offset;
            ph.vaddr = raw.p_vaddr;
            ph.filesz = raw.p_filesz;
            ph.memsz = raw.p_memsz;
            ph.align = raw.p_align;
        }
        out.push_back(ph);
    }
    return out;
}

// ---------------------------------------------------------------- dynamic symbols

namespace {

struct DynInfo {
    uint64_t symtab = 0, strtab = 0, strsz = 0;
    uint64_t syment = 0;
    uint64_t hash = 0;       // DT_HASH
    uint64_t gnu_hash = 0;   // DT_GNU_HASH
    bool has_symtab = false, has_strtab = false;
};

bool read_dynamic_tags(RemoteMemory &mem, uintptr_t base, const ProgramHeader &dyn_ph,
                        bool is64, DynInfo &out) {
    uint64_t count = dyn_ph.memsz / (is64 ? sizeof(Elf64_Dyn) : sizeof(Elf32_Dyn));
    if (count == 0 || count > 4096) return false;

    for (uint64_t i = 0; i < count; ++i) {
        int64_t tag;
        uint64_t val;
        uintptr_t addr = base + dyn_ph.vaddr + i * (is64 ? sizeof(Elf64_Dyn) : sizeof(Elf32_Dyn));

        if (is64) {
            Elf64_Dyn d{};
            if (!mem.read(addr, &d, sizeof(d))) return false;
            tag = d.d_tag;
            val = d.d_un.d_val;
        } else {
            Elf32_Dyn d{};
            if (!mem.read(addr, &d, sizeof(d))) return false;
            tag = d.d_tag;
            val = d.d_un.d_val;
        }

        if (tag == DT_NULL) break;
        switch (tag) {
            case DT_SYMTAB: out.symtab = val; out.has_symtab = true; break;
            case DT_STRTAB: out.strtab = val; out.has_strtab = true; break;
            case DT_STRSZ:  out.strsz = val; break;
            case DT_SYMENT: out.syment = val; break;
            case DT_HASH:   out.hash = val; break;
            case DT_GNU_HASH: out.gnu_hash = val; break;
            default: break;
        }
    }
    return out.has_symtab && out.has_strtab;
}

// Classic DT_HASH: nchain == total number of symbol table entries.
bool symbol_count_from_dt_hash(RemoteMemory &mem, uintptr_t base, uint64_t hash_vaddr,
                                uint32_t &out_count) {
    uint32_t header[2]; // nbucket, nchain
    if (!mem.read(base + hash_vaddr, header, sizeof(header))) return false;
    if (header[1] == 0 || header[1] > 200000) return false; // sanity
    out_count = header[1];
    return true;
}

// DT_GNU_HASH doesn't store an explicit count. Standard approach: walk
// the bucket array to find the highest symbol index any bucket points
// at, then walk that chain forward (chain values have LSB=1 on the last
// entry of each chain) until we pass the last-used chain slot.
bool symbol_count_from_gnu_hash(RemoteMemory &mem, uintptr_t base, uint64_t gnu_hash_vaddr,
                                 bool is64, uint32_t &out_count) {
    struct GnuHashHeader { uint32_t nbuckets; uint32_t symoffset; uint32_t bloom_size; uint32_t bloom_shift; };
    GnuHashHeader h{};
    if (!mem.read(base + gnu_hash_vaddr, &h, sizeof(h))) return false;
    if (h.nbuckets == 0 || h.nbuckets > 200000) return false;
    if (h.symoffset > 200000) return false;

    // Bloom filter words are ElfW(Addr)-sized: 8 bytes on arm64, 4 on armv7.
    const size_t word_size = is64 ? 8 : 4;

    uintptr_t buckets_addr = base + gnu_hash_vaddr + sizeof(GnuHashHeader)
                              + (size_t) h.bloom_size * word_size;
    std::vector<uint32_t> buckets(h.nbuckets);
    if (!mem.read(buckets_addr, buckets.data(), buckets.size() * sizeof(uint32_t))) return false;

    uint32_t max_idx = 0;
    bool any = false;
    for (uint32_t b : buckets) {
        if (b == 0) continue;
        any = true;
        if (b > max_idx) max_idx = b;
    }
    if (!any) { out_count = h.symoffset; return true; }

    uintptr_t chain_addr = buckets_addr + h.nbuckets * sizeof(uint32_t);
    uint32_t idx = max_idx;
    for (int guard = 0; guard < 200000; ++guard) {
        uint32_t chain_val;
        if (!mem.read(chain_addr + (uint64_t)(idx - h.symoffset) * sizeof(uint32_t),
                      &chain_val, sizeof(chain_val))) {
            // Can't walk further; return best-known lower bound.
            out_count = idx + 1;
            return true;
        }
        if (chain_val & 1u) { out_count = idx + 1; return true; }
        ++idx;
    }
    out_count = idx; // guard tripped, still usable as a bound
    return true;
}

std::string read_c_string(RemoteMemory &mem, uintptr_t addr, size_t max_len = 256) {
    std::string result;
    char chunk[32];
    size_t read_total = 0;
    while (read_total < max_len) {
        size_t want = sizeof(chunk);
        if (!mem.read(addr + read_total, chunk, want)) break;
        for (size_t i = 0; i < want; ++i) {
            if (chunk[i] == '\0') return result;
            result.push_back(chunk[i]);
        }
        read_total += want;
    }
    return result;
}

} // namespace

std::set<std::string> read_dynamic_symbol_names(RemoteMemory &mem, uintptr_t base,
                                                  const std::vector<ProgramHeader> &phdrs,
                                                  const ElfIdentity &id) {
    std::set<std::string> names;

    const ProgramHeader *dyn_ph = nullptr;
    for (const auto &ph : phdrs) {
        if (ph.type == PT_DYNAMIC) { dyn_ph = &ph; break; }
    }
    if (!dyn_ph) return names;

    DynInfo dyn;
    if (!read_dynamic_tags(mem, base, *dyn_ph, id.is64, dyn)) return names;

    uint32_t sym_count = 0;
    if (dyn.hash) {
        symbol_count_from_dt_hash(mem, base, dyn.hash, sym_count);
    }
    if (sym_count == 0 && dyn.gnu_hash) {
        symbol_count_from_gnu_hash(mem, base, dyn.gnu_hash, id.is64, sym_count);
    }
    if (sym_count == 0) {
        // Last resort: bound by strtab distance (works when the linker laid
        // symtab immediately before strtab, true for essentially every
        // Android NDK toolchain output).
        if (dyn.strtab <= dyn.symtab) return names;
        uint64_t syment = dyn.syment ? dyn.syment : (id.is64 ? sizeof(Elf64_Sym) : sizeof(Elf32_Sym));
        sym_count = (uint32_t) ((dyn.strtab - dyn.symtab) / syment);
    }
    if (sym_count == 0 || sym_count > 300000) return names;

    uint64_t syment = dyn.syment ? dyn.syment : (id.is64 ? sizeof(Elf64_Sym) : sizeof(Elf32_Sym));

    for (uint32_t i = 0; i < sym_count; ++i) {
        uintptr_t sym_addr = base + dyn.symtab + (uint64_t) i * syment;
        uint32_t name_off = 0;

        if (id.is64) {
            Elf64_Sym s{};
            if (!mem.read(sym_addr, &s, sizeof(s))) continue;
            if (s.st_name == 0 || s.st_shndx == SHN_UNDEF) continue; // skip imports, we want exports
            name_off = s.st_name;
        } else {
            Elf32_Sym s{};
            if (!mem.read(sym_addr, &s, sizeof(s))) continue;
            if (s.st_name == 0 || s.st_shndx == SHN_UNDEF) continue;
            name_off = s.st_name;
        }

        std::string nm = read_c_string(mem, base + dyn.strtab + name_off);
        if (!nm.empty()) names.insert(nm);
    }

    return names;
}

const std::vector<std::string> &il2cpp_required_exports() {
    static const std::vector<std::string> kExports = {
        "il2cpp_init",
        "il2cpp_domain_get",
        "il2cpp_class_from_name",
        "il2cpp_class_get_method_from_name",
        "il2cpp_object_new",
        "il2cpp_thread_attach",
        "il2cpp_runtime_invoke",
        "il2cpp_string_new",
        "il2cpp_array_new",
        "il2cpp_assembly_get_image",
    };
    return kExports;
}

int count_il2cpp_exports_present(const std::set<std::string> &found) {
    int n = 0;
    for (const auto &exp : il2cpp_required_exports()) {
        if (found.count(exp)) ++n;
    }
    return n;
}
